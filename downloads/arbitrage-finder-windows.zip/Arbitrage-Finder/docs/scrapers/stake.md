# Stake Scraper Setup

## 1. Status and scope

This guide explains how to configure the `stake` source profile in Arbitrage Finder for public, anonymous pre-match prices from `https://stake.com/`. The exact domain was confirmed by the intended user. The scraper framework and fixture-based parsers are implemented. **No live site-specific Stake extraction mapping was validated for this release.**

That distinction matters: a source profile with this bookmaker's name is not a ready-made verified feed. You still need to inspect an accessible public page, identify fields, confirm settlement and active-state handling, and validate the resulting quotes. The cloud environment used for development has restricted outbound access. An actual HTTPS probe to Bet365 received a platform-proxy CONNECT denial (HTTP 403); the other requested bookmaker/API domains were absent from the initial allowed list and were not live-tested. These development-environment facts do not establish whether your own Windows 11 machine can read this public site.

There is no confirmed free documented Stake API bundled with the project. The optional aggregator connector is a separate route whose current free plan and bookmaker coverage must be checked with its provider. This guide does not assert that the aggregator supplies Stake.

The supported route here requires no bookmaker account login. It does not import cookies or use a CAPTCHA solver, stealth extension, paid proxy service, or account token. If the site cannot expose usable public odds under its rules, this source remains unavailable.

## 2. Prepare Windows 11

Open PowerShell in the checkout containing `pyproject.toml` and `uv.lock`. Install the base environment and start the local application.

```powershell
uv sync --frozen
uv run arbscanner
```

If uv is installed as a Python module rather than a command on PATH, use `py -3.12 -m uv` in place of `uv`. Open `http://127.0.0.1:8000` and keep the terminal running. In the dashboard, use Data sources to edit the `stake` profile. Keep it disabled while establishing the mapping.

HTML and JSON modes need no browser download. If the verified public page requires JavaScript rendering, install the optional browser components:

```powershell
uv sync --frozen --extra browser
uv run playwright install chromium
```

Browser rendering is optional. It cannot supply missing access rights or account data, and it does not guarantee that this bookmaker's current frontend works in anonymous automated Chromium.

## 3. Establish the real public data route

1. Open `https://stake.com/` in an InPrivate or private browser window without logging in.
2. Locate the intended pre-match sportsbook, then one league or future event.
3. Confirm that prices, participant names, event start, market title, and line are visible anonymously.
4. Check the target's applicable automation and data-use rules and its robots instructions.
5. Record the exact URL, language, sport, league, market, and date of inspection.
6. Choose HTML, public JSON, or browser mode based on the actual data you observe.
7. Stop if the relevant information requires login, returns an access denial, or presents a challenge.

Stake sports, esports, and casino pages are different products. Use a sportsbook fixture or league page and confirm the participants and market are visible without signing in. A casino page, promotion, or account-currency widget is not an odds source. Anonymous browser mode rejects non-GET requests, so a sportsbook that only supplies its data through POST operations may be unavailable to that mode.

A browser's developer tools can show the DOM and public network responses used by the page. Inspect only the public anonymous route. Do not export or paste an authenticated request with authorization headers, passwords, cookies, or session tokens into source settings.

### 3.1 Choose the mode

Use `html` when a normal public GET response contains the relevant event and odds elements. Use `json` only for a public response you can request legitimately without authentication. Use `browser` when the public document becomes readable only after JavaScript rendering and its required GET resources are permitted.

The browser route permits only configured public hosts and subdomains and rejects non-GET operations. Some frontends need POST requests or vendor resources. Add only verified necessary public hosts; if a required operation is unsupported, record the limitation rather than bypassing it.

## 4. Confirm the betting contract

Separate sports from esports, and distinguish match winner from map or set winner. Confirm the displayed decimal format and that your quote currency label is an accounting assumption, not a conversion of a cryptocurrency balance.

For a first setup, choose only one simple market family on a narrow page. Supported canonical markets are `h2h_2way`, `h2h_3way`, `totals`, and `spreads`. Only half-line totals and spreads are accepted. Integer pushes, Asian quarter lines, props requiring different payoff rules, dead heats, and partial wins are not modeled.

Set `period` and `rules` explicitly after checking the actual market. A generic `full_time` / `regulation` constant must not be applied to a page mixing overtime-inclusive winner markets, first-half results, and whole-match outcomes. Set `rules_confirmed` to true only after these semantics and the suspended-odds filtering are established.

## 5. Map HTML fields

The example below demonstrates the configuration language on a controlled page structure. **The CSS classes are illustrative and are not known Stake selectors.** Replace every example selector with a value inspected on the actual public page. Replace the league and other constants with verified values that apply to every selected row.

```json
{
  "mode": "html",
  "url": "https://stake.com/",
  "allowed_hosts": ["stake.com"],
  "min_interval_seconds": 10,
  "max_pages": 1,
  "pages": [],
  "rules_confirmed": false,
  "event_selector": ".fixture",
  "quote_selector": ".selection[data-status='open']",
  "inactive_selector": ".suspension-flag",
  "constants": {
    "sport": "soccer",
    "league": "REPLACE WITH VERIFIED LEAGUE",
    "market": "h2h_3way",
    "period": "full_time",
    "rules": "regulation",
    "currency": "EUR"
  },
  "mapping": {
    "home": {"selector": ".home", "scope": "event"},
    "away": {"selector": ".away", "scope": "event"},
    "starts_at": {
      "selector": "time", "scope": "event", "attr": "datetime"
    },
    "source_updated_at": {
      "scope": "event", "attr": "data-updated"
    },
    "outcome": {
      "attr": "data-side",
      "values": {"1": "home", "X": "draw", "2": "away"}
    },
    "odds": ".decimal-price"
  }
}
```

`event_selector` selects one event container. `quote_selector` selects offered outcome rows inside it. A mapping with `scope: event` reads event-level fields; otherwise it reads the quote row. With no selector inside an object mapping, the chosen container itself supplies the named attribute. Text is the default when no attribute is specified.

The example active selector requires a row marked open, and `inactive_selector` also rejects a matching suspension descendant. Inspect the real site's actual disabled and suspended behavior. A marker on the row itself may require filtering in `quote_selector`; `inactive_selector` looks inside the row. Do not set these fields merely to satisfy a form without establishing their meaning.

The `values` mapping translates only explicitly listed source labels. Change those labels to what the public source actually supplies. A missing or unknown code is not a reason to guess. The parser rejects unusable rows rather than inventing an outcome.

## 6. Map a public JSON response

A JSON route may represent a flat list of quotes or nested events, markets, and selections. The following excerpt demonstrates nested scope paths. It is not a documented Stake payload or endpoint.

```json
{
  "mode": "json",
  "events_path": "events",
  "markets_path": "markets",
  "outcomes_path": "selections",
  "active_path": "$quote.status",
  "active_values": ["open"],
  "mapping": {
    "home": "$event.home",
    "away": "$event.away",
    "starts_at": "$event.start",
    "source_updated_at": "$market.updated_at",
    "market": {
      "path": "$market.code",
      "values": {"VERIFIED_RESULT_CODE": "h2h_3way"}
    },
    "outcome": {
      "path": "$quote.side",
      "values": {"1": "home", "X": "draw", "2": "away"}
    },
    "odds": "$quote.decimal_price"
  }
}
```

Merge the needed URL, allowed hosts, confirmed rules, constants, and limits from your actual source configuration. For a flat response, use `items_path` and map paths relative to each row instead. Dotted paths support dictionary keys, numeric indexes, and `*` wildcards. The mapping language does not execute code.

Timestamps may be ISO 8601 strings with a UTC offset. If a source supplies a verified Unix timestamp, use a mapping object with `format: unix` or `format: unix_ms` as appropriate. These formats are explicit; the parser does not infer whether a number represents seconds or milliseconds.

For verified nondecimal prices, add `format: american` or `format: fractional` to the odds mapping object. A JSON example is `"odds": {"path": "$quote.price", "format": "american"}`. American +150 becomes 2.50 and -200 becomes 1.50; fractional 5/2 becomes 3.50. Do not set a conversion format on prices that are already decimal. Invalid or impossible values are rejected.

Numeric transforms can multiply a value. A spread's canonical line is always the home handicap; when the source expresses the away selection's own handicap, it must be sign-reversed for that away row. Do not apply a negative multiplier to all rows unless that matches the actual source structure.

## 7. Treat timestamps honestly

`observed_at` is set when the scraper reads the page. `source_updated_at` is an actual source-provided odds update time when available. They are different facts. Never put the current time into a constant called `source_updated_at` just to make a scan pass.

The scanner requires source timestamps by default. If the public page provides none, the source can still extract quotes, but strict scan settings reject them as unknown source age. You may explicitly disable that requirement if you accept the limitation; resulting opportunities warn that actual odds age is unknown. Refreshing HTML does not prove that a displayed price was freshly updated.

Use explicit timezones for starts and updates. A page saying only 20:00 is insufficient without a verified date and timezone. Albania's local clock changes with daylight saving time; an assumed constant offset can misidentify events. Prefer a genuine UTC or offset-bearing source timestamp.

## 8. Save and run one narrow scan

1. Finish the real URL and field mapping in Data sources for `stake`.
2. Set `rules_confirmed` to true only after checking the contract and active-state handling.
3. Enable this source and disable unrelated unconfigured sources.
4. Keep `max_pages` at 1 for the first check.
5. Select live mode and press Scan once.
6. Read source status, quote count, rejected rows, and the scan's rejection reasons.
7. Open the extracted quote preview and compare canonical fields with the actual public display before adding another source. The preview includes up to 100 collected quotes even when no opportunity passes.

A cooldown prevents immediate repeated requests. The page scraper waits between requests and honors applicable robots crawl delay. Additional configured pages are bounded to a maximum of three per source attempt. Several pages can exceed the outer scan timeout, so keep a first setup narrow and choose a request interval that respects the source.

A successful extraction from one bookmaker usually cannot produce a cross-bookmaker opportunity on its own. Configure a second source for the exact same event and contract. Names, league, sport, scheduled instant, home/away order, period, line, rules, and currency must match after the limited normalization used by the engine.

## 9. Validate before trusting results

Create a record of at least these checks:

- A known future event has the correct participants, league, start, and timezone.
- Every selected odds value is a decimal price currently offered publicly.
- All outcomes of a complete supported market are captured.
- A suspended selection is rejected.
- A missing price, unknown outcome code, and malformed timestamp are rejected.
- A known source update remains distinct from retrieval time.
- A total or spread uses an identical canonical half line across sources.
- A page mixing periods or rules cannot collapse them into one contract.
- An intentionally non-arbitrage sample produces no opportunity.

Run controlled parser tests from the checkout root:

```powershell
uv run pytest tests/test_connectors.py
```

These tests prove fixture parsing and connector behavior, not current live Stake coverage. For a real verification record, include the date, exact domain, public page, mode, market, normalized sample, and observed limitations. Keep passwords, account data, cookies, and API secrets out of any fixture or report.

## 10. Troubleshooting this profile

**Unconfigured:** inspect the URL, actual mapping, rules confirmation, selectors or paths, and constants. The shipped profile starts deliberately incomplete.

**Blocked:** read the message for robots, denial, challenge, login, or regional access restrictions. Do not add authenticated cookies or evasion tools. Confirm whether the target is genuinely public on the intended computer.

**No valid quotes:** inspect current markup or JSON; check active-state filtering, decimal prices, timezone-aware timestamps, required fields, and market classification. The source may have changed its layout.

**Quotes collected but no opportunities:** inspect source-age rejection, exact event identity, all required outcomes, currency, minimum profit, and the need for a second bookmaker. Zero opportunities can be the correct result.

**Very high apparent profit:** disable the source and check participant orientation, periods, lines, outcome translations, and stale prices. An unexplained extreme result is a mapping problem until you have verified every leg.

**Browser resources blocked:** identify only the necessary public resource domains and supported GET operations. A site requiring POST, login, unsupported rendering, or a challenge may remain unavailable.

## 11. Expand and maintain

After a narrow verification succeeds, add only compatible sports, leagues, and markets. Use dynamic field mappings rather than a single false constant on a mixed page. Do not treat every visible number as an odds quote. Keep each market period and settlement contract explicit.

Recheck this profile when the site changes its layout, routes, labels, or access behavior. Re-run the controlled tests and one manual real-page check. If parsing becomes uncertain, disable the profile until it is corrected. Save sanitized fixtures for your verified structure so future code changes can be tested without repeatedly contacting the site.

## 12. Completion record

Before calling this a working Stake integration, record the actual public URL, regional domain, mode, inspected mapping version, sport and market coverage, active-state test, timestamp availability, known limitations, verification date, and comparison against the public page. Until that evidence exists, retain the unverified status. A working generic scraper is the tool for completing this setup; it is not evidence that this bookmaker currently provides an accessible free feed.
